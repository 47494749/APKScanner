import sys
from androguard.core.bytecodes.axml import AXMLPrinter

# Controlla se è stato passato un argomento
if len(sys.argv) != 2:
    print("Utilizzo: python3 script.py <nomefile.xml>")
    sys.exit(1)

# Legge il nome del file dalla linea di comando
file_name = sys.argv[1]

try:
    # Legge il file binario
    with open(file_name, "rb") as f:
        binary_xml = f.read()

    # Decodifica il file XML binario
    xml_printer = AXMLPrinter(binary_xml)
    original_bytes = xml_printer.get_xml()  # Restituisce bytes
    original_string = original_bytes.decode("utf-8")  # Decodifica in str
    converted_string = original_string.replace("\n", "\r\n")  # Converte \n in \r\n
    print(converted_string)
except FileNotFoundError:
    print(f"Errore: File '{file_name}' non trovato.")
except Exception as e:
    print(f"Errore: {e}")
